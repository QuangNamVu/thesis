class LibraryController < ApplicationController
  def index
  end
end
